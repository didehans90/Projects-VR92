import java.util.ArrayList;
import java.util.Scanner;

class Product {
    String name;
    int quantity;
    double price;

    public Product(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public double getTotalPrice() {
        return quantity * price;
    }
}

public class cashier {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter Customer Name: ");  
        String customerName = scanner.nextLine();
        
        System.out.print("Enter Customer Address: ");  
        String customerAddress = scanner.nextLine();
        
        ArrayList<Product> productList = new ArrayList<>();  
        
        System.out.print("Enter the number of products purchased: ");
        int numProducts = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numProducts; i++) {
            System.out.println("Product Details No: " + (i + 1) + ":");
            System.out.print("Product Name: ");
            String name = scanner.nextLine();

            System.out.print("Quantity: ");
            int quantity = scanner.nextInt();

            System.out.print("Price per unit: ");
            double price = scanner.nextDouble();
            scanner.nextLine();
            
            productList.add(new Product(name, quantity, price));
        }

        
        double totalCost = 0;
        for (Product product : productList) {
            totalCost += product.getTotalPrice();
        }

       
        double discount = 0;
        if (numProducts == 2) {
            discount = 0.10; // 10% 
        } else if (numProducts == 3) {
            discount = 0.30; // 30% 
        }

        double discountAmount = totalCost * discount;
        double finalAmount = totalCost - discountAmount;

        System.out.println("\n======= CASHIER RECEIPT ======="); 
        System.out.println("Customer: " + customerName);
        System.out.println("Address: " + customerAddress);
        System.out.println("---------------------------------");
        
        for (Product product : productList) {
            System.out.printf("%s (x%d) - Rp%.2f\n", product.name, product.quantity, product.getTotalPrice());
        }

        System.out.println("---------------------------------");
        System.out.printf("Subtotal: Rp%.2f\n", totalCost);
        System.out.printf("Discount: %.0f%% (-Rp%.2f)\n", discount * 100, discountAmount);
        System.out.printf("Total: Rp%.2f\n", finalAmount);
        System.out.println("=================================");
        
        scanner.close();
    }
}